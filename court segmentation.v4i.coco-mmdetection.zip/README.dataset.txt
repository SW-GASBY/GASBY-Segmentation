# court segmentation > 2024-01-09 11:16pm
https://universe.roboflow.com/zy-vevvi/court-segmentation

Provided by a Roboflow user
License: CC BY 4.0

